import java.io.IOException;
import java.net.*;

public class Server {
    public static void main(String[] args) throws IOException {
        while (true){
            // Establecemos el socket
            DatagramSocket ds = new DatagramSocket(8888); // puerto en el que recibe

            // definir el tamaño bytes recibe como mensaje
            byte[] buffer = new byte[1024];

            // crea datagrama con el buffer
            DatagramPacket dp = new DatagramPacket(buffer, 1024);

            // espera a recibir mensajes
            ds.receive(dp);

            // los pasa a un string
            String mensaje = new String(dp.getData(), 0, dp.getLength());

            // los imprime
            System.out.println(mensaje);

            // cerrar el puerto
            ds.close();
        }
    }
}