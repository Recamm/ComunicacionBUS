import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Random;

public class Client {

    static String generarPalabra(int longitud) {
        String letras = "abcdefghijklmnopqrstuvwxyz";
        Random random = new Random();
        StringBuilder palabra = new StringBuilder();

        for (int i = 0; i < longitud; i++) {
            int index = random.nextInt(letras.length());
            palabra.append(letras.charAt(index));
        }

        return palabra.toString();
    }

    public static void main(String[] args) throws IOException {
        // Creamos un socket
        DatagramSocket ds = new DatagramSocket();

        // Mensaje
        // String menssage = "camilo no sabe programar";

        // IP destino

        // para mandarse a si mismo
        // InetAddress ipyo = InetAddress.getByName("localhost");

        // para mandarle a otro por ip
         String ipAddress = "172.16.4.249";
        // String ipAddress = "172.16.4.186";
        InetAddress address = InetAddress.getByName(ipAddress);

        // Transformar el mensaje en un datagrama
        // DatagramPacket dp = new DatagramPacket(menssage.getBytes(), menssage.length(), address, 2048);

        for (int i = 0; i < 100000000; i++) {
            //String menssage = generarPalabra(10);
            String menssage = "Hagan el curso de cisco";
            DatagramPacket dp = new DatagramPacket(menssage.getBytes(), menssage.length(), address, 10001);
            ds.send(dp);
        }


        // Enviar el mensaje
        // ds.send(dp);

        // Cerrar la conexion
        ds.close();
    }
}
