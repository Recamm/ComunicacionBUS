package tcpHilos;

import java.io.*;
import java.net.Socket;

public class TCPServerThread implements Runnable {
    private String claveInicio = "hola", claveFin = "chau";
    public boolean loop = false;
    private Socket socket; // Client socket
    private TCPServerMain tcpServerMain; // Reference to the main server

    public TCPServerThread(Socket socket, TCPServerMain tcpServerMain) {
        this.socket = socket;
        this.tcpServerMain = tcpServerMain;
    }

    @Override
    public void run() {
        try {
            int clientNumber = tcpServerMain.getClientNumber();
            System.out.println("Cliente " + clientNumber + " en " + socket.getInetAddress() + " se ha conectado.");

            // Set up input and output streams for client communication
            BufferedReader in_socket = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter out_socket = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

            // Initial message to the client
            // out_socket.println("Welcome to TCP Server!");

            while (true){
                // Read and print the client's message
                String message = in_socket.readLine();
                if (message.equals(claveInicio) && !loop){
                    loop = true;
                    out_socket.println(claveInicio);
                    System.out.println("Conexion establecida!");
                }
                if (loop) {
                    System.out.println("Cliente -- > " + message);
                    out_socket.println("Mensaje recibido!");
                }
                if (message.equals(claveFin) && loop){
                    System.out.println("Conexion finalizada!");
                    socket.close();
                    out_socket.println(claveFin);
                    System.out.println("Cliente " + clientNumber + " " + socket.getInetAddress() + " desconectado.");
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}