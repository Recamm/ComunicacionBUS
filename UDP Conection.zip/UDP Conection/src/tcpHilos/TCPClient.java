package tcpHilos;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class TCPClient {
    private String claveInicio = "hola", claveFin = "chau";
    private boolean loop = false;
    TCPClient() throws IOException {

        // Connect to the server at localhost on port 2020
        Socket socket = new Socket("localhost", 2020);
        // System.out.println("Successfully connected to the server.");

        // Set up input and output streams for communication
        BufferedReader in_socket = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintWriter out_socket = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
        Scanner keyboard = new Scanner(System.in);

        while (true){
            // Send a message to the server
            System.out.print("-> ");
            String message = keyboard.nextLine();
            out_socket.println(message);

            String messageReci = in_socket.readLine();
            if (messageReci.equals(claveInicio) && !loop) {
                System.out.println("Conexion establecida");
            }
            if (loop){
                System.out.println("Servidor --> " + messageReci);
            }
            if (messageReci.equals(claveFin) && loop){
                System.out.println("Conexion finalizada");
                socket.close();

            }
        }
    }

    public static void main(String[] args) {

        try {
            new TCPClient(); // Start the client

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}