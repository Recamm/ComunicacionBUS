import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class cliente2 {
    public static void main(String[] args) throws IOException {
        // Creamos un socket
        DatagramSocket ds = new DatagramSocket();

        // Mensaje
         String menssage = "end";

        // IP destino

        // para mandarse a si mismo
        // InetAddress ipyo = InetAddress.getByName("localhost");

        // para mandarle a otro por ip
        String ipAddress = "172.16.4.186";
        InetAddress address = InetAddress.getByName(ipAddress);

        // Transformar el mensaje en un datagrama
         DatagramPacket dp = new DatagramPacket(menssage.getBytes(), menssage.length(), address, 8888);


        // Enviar el mensaje
         ds.send(dp);

        // Cerrar la conexion
        ds.close();
    }
}
