package tcp_hilos;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Cliente {
    public static void main(String[] args) throws IOException {
        boolean conexion = false, bucle = true;
        String claveInicio = "hola";
        String claveFin = "adios";
        try {
            Scanner scn = new Scanner(System.in);

            // IP Destinatario
            InetAddress ip = InetAddress.getByName("localhost");
            // InetAddress ip = InetAddress.getByName("localhost");

            // Puerto Destinatario
            Socket s = new Socket(ip, 8888);

            // Obteniendo ouputs e inputs
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            // El bucle hace el cambio entre el cliente y el hilo
            while (bucle)
            {
                // System.out.println(dis.readUTF());
                if (!conexion) {
                    dos.writeUTF(claveInicio);
                }

                if (!dis.readUTF().isEmpty()){
                    String recibir = dis.readUTF();
                    if (recibir.equals(claveInicio)) {
                        conexion = true;
                    }
                }

                while (true){
                    String tosend = scn.nextLine();
                    dos.writeUTF(tosend);
                    if(tosend.equals(claveFin)){
                        bucle = false;
                        while (true) {
                            if (dis.readUTF().equals(claveFin)) {
                                System.out.println("Conexion finalizada!");
                                break;
                            }
                        }
                        break;
                    }
                }
            }

            // closing resources
            scn.close();
            dis.close();
            dos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}