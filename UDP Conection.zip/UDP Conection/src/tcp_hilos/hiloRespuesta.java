package tcp_hilos;

import java.io.*;
import java.text.*;
import java.util.*;
import java.net.*;

public class hiloRespuesta extends Thread{
    String claveInicio = "hola";
    String claveFin = "adios";
    boolean condicionWhile = true, inicioConexion = false;

    // DateFormat fordate = new SimpleDateFormat("yyyy/MM/dd");
    // DateFormat fortime = new SimpleDateFormat("hh:mm:ss");
    final DataInputStream dis;
    final DataOutputStream dos;
    final Socket s;


    // Constructor
    public hiloRespuesta(Socket s, DataInputStream dis, DataOutputStream dos) {
        this.s = s;
        this.dis = dis;
        this.dos = dos;
    }

    @Override
    public void run() {
        String toreturn;
        String recibir;
        while (condicionWhile) {
            try {
                if(dis.readUTF().toLowerCase().equals(claveInicio) && !inicioConexion){
                    dos.writeUTF(claveInicio);
                    inicioConexion = true;
                    System.out.println("Conexion iniciada");
                }

                if (inicioConexion) {
                    recibir = dis.readUTF();
                    if (!recibir.isEmpty()){
                        System.out.println("Mensaje recibido");
                        dos.writeUTF("Mensaje recibido");
                    }
                    if(recibir.equals(claveFin)){
                        dos.writeUTF(claveFin);
                        condicionWhile = false;
                        s.close();
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}