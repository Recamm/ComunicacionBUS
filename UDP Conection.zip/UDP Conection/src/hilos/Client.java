package hilos;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) throws IOException {
        try {
            Scanner scn = new Scanner(System.in);

            // IP Destinatario
            InetAddress ip = InetAddress.getByName("localhost");
            // InetAddress ip = InetAddress.getByName("localhost");

            // Puerto Destinatario
            Socket s = new Socket(ip, 8888);

            // Obteniendo ouputs e inputs
            DataInputStream dis = new DataInputStream(s.getInputStream());
            DataOutputStream dos = new DataOutputStream(s.getOutputStream());

            // El bucle hace el cambio entre el cliente y el hilo
            while (true)
            {
                System.out.println(dis.readUTF());
                String tosend = scn.nextLine();
                dos.writeUTF(tosend);

                // Si el cliente envia exit, cierra la conexion y despues sale del while
                if(tosend.equals("Exit")) {
                    System.out.println("Cerrando conexion : " + s);
                    s.close();
                    System.out.println("Conexion cerrada");
                    break;
                }

                // printing date or time as requested by client
                String received = dis.readUTF();
                System.out.println(received);
            }

            // closing resources
            scn.close();
            dis.close();
            dos.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}